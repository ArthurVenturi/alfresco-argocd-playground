# Deploy Alfresco Plataform in K8s

## 

##
